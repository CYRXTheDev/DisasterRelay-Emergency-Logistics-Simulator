extends CanvasLayer
## HUD, pause menu and end-game overlay controller.

@onready var time_label: Label = $Top/HBox/TimeLabel
@onready var fuel_label: Label = $Top/HBox/FuelLabel
@onready var health_label: Label = $Top/HBox/HealthLabel
@onready var rescued_label: Label = $Top/HBox/RescuedLabel
@onready var supplies_label: Label = $Top/HBox/SuppliesLabel
@onready var objective_label: Label = $Top/ObjectiveLabel

@onready var pause_panel: Control = $PausePanel
@onready var end_panel: Control = $EndPanel
@onready var end_title: Label = $EndPanel/Panel/VBox/TitleLabel
@onready var end_message: Label = $EndPanel/Panel/VBox/MessageLabel

var _paused := false

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS

	Game.fuel_changed.connect(_on_fuel_changed)
	Game.health_changed.connect(_on_health_changed)
	Game.time_changed.connect(_on_time_changed)
	Game.rescued_changed.connect(_on_rescued_changed)
	Game.supplies_changed.connect(_on_supplies_changed)
	Game.game_over_triggered.connect(_on_game_over)
	Game.victory_triggered.connect(_on_victory)

	$PausePanel/Panel/VBox/ResumeButton.pressed.connect(_on_resume_pressed)
	$PausePanel/Panel/VBox/MenuButton.pressed.connect(_on_menu_pressed)
	$EndPanel/Panel/VBox/RetryButton.pressed.connect(_on_retry_pressed)
	$EndPanel/Panel/VBox/MenuButton2.pressed.connect(_on_menu_pressed)

	_update_objective()
	_on_fuel_changed(Game.fuel)
	_on_health_changed(Game.health)
	_on_time_changed(Game.time_left)
	_on_rescued_changed(Game.rescued)
	_on_supplies_changed(Game.supplies)

func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("ui_cancel") and Game.game_active:
		_toggle_pause()

func _toggle_pause() -> void:
	_paused = not _paused
	get_tree().paused = _paused
	pause_panel.visible = _paused

func _on_resume_pressed() -> void:
	_toggle_pause()

func _on_menu_pressed() -> void:
	get_tree().paused = false
	get_tree().change_scene_to_file("res://scenes/ui/main_menu.tscn")

func _on_retry_pressed() -> void:
	get_tree().paused = false
	get_tree().change_scene_to_file("res://scenes/main.tscn")

func _on_fuel_changed(v: float) -> void:
	fuel_label.text = "Fuel: %d" % int(v)

func _on_health_changed(v: float) -> void:
	health_label.text = "Health: %d" % int(v)

func _on_time_changed(v: float) -> void:
	time_label.text = "Time: %d" % int(v)

func _on_rescued_changed(v: int) -> void:
	rescued_label.text = "Rescued: %d/%d" % [v, Game.RESCUE_TARGET]
	_update_objective()

func _on_supplies_changed(v: int) -> void:
	supplies_label.text = "Supplies: %d/%d" % [v, Game.SUPPLY_TARGET]
	_update_objective()

func _update_objective() -> void:
	objective_label.text = "Objective: Rescue %d civilians & deliver %d supplies" % [Game.RESCUE_TARGET, Game.SUPPLY_TARGET]

func _on_game_over(reason: String) -> void:
	end_title.text = "Game Over"
	end_message.text = reason
	end_panel.visible = true

func _on_victory() -> void:
	end_title.text = "Victory!"
	end_message.text = "All objectives complete!"
	end_panel.visible = true
