extends Area2D
## Relief supply crate. Player touches it -> delivered.

func _ready() -> void:
	body_entered.connect(_on_body_entered)

func _on_body_entered(body: Node2D) -> void:
	if body.is_in_group("player"):
		Game.add_supplies()
		queue_free()
