extends Node
## Autoload "Game": central game state for DisasterRelay.

signal fuel_changed(value: float)
signal health_changed(value: float)
signal time_changed(value: float)
signal rescued_changed(value: int)
signal supplies_changed(value: int)
signal game_over_triggered(reason: String)
signal victory_triggered

const MAX_FUEL := 100.0
const MAX_HEALTH := 100.0
const LEVEL_TIME := 120.0
const FUEL_DRAIN_MOVING := 3.0
const FUEL_DRAIN_IDLE := 0.4
const HAZARD_DAMAGE_RATE := 15.0

const RESCUE_TARGET := 4
const SUPPLY_TARGET := 4

var fuel: float = MAX_FUEL
var health: float = MAX_HEALTH
var time_left: float = LEVEL_TIME
var rescued: int = 0
var supplies: int = 0
var game_active: bool = false

func reset_game() -> void:
	fuel = MAX_FUEL
	health = MAX_HEALTH
	time_left = LEVEL_TIME
	rescued = 0
	supplies = 0
	game_active = true
	fuel_changed.emit(fuel)
	health_changed.emit(health)
	time_changed.emit(time_left)
	rescued_changed.emit(rescued)
	supplies_changed.emit(supplies)

func _process(delta: float) -> void:
	if not game_active:
		return
	time_left = max(0.0, time_left - delta)
	time_changed.emit(time_left)
	if time_left <= 0.0:
		trigger_game_over("Time's up!")

func consume_fuel(moving: bool, delta: float) -> void:
	if not game_active:
		return
	var rate := FUEL_DRAIN_MOVING if moving else FUEL_DRAIN_IDLE
	fuel = max(0.0, fuel - rate * delta)
	fuel_changed.emit(fuel)
	if fuel <= 0.0:
		trigger_game_over("Out of fuel!")

func damage_health(amount: float) -> void:
	if not game_active:
		return
	health = max(0.0, health - amount)
	health_changed.emit(health)
	if health <= 0.0:
		trigger_game_over("Vehicle destroyed by floodwaters!")

func add_rescued() -> void:
	if not game_active:
		return
	rescued += 1
	rescued_changed.emit(rescued)
	_check_victory()

func add_supplies() -> void:
	if not game_active:
		return
	supplies += 1
	supplies_changed.emit(supplies)
	_check_victory()

func _check_victory() -> void:
	if rescued >= RESCUE_TARGET and supplies >= SUPPLY_TARGET:
		trigger_victory()

func trigger_game_over(reason: String) -> void:
	if not game_active:
		return
	game_active = false
	game_over_triggered.emit(reason)

func trigger_victory() -> void:
	if not game_active:
		return
	game_active = false
	victory_triggered.emit()
