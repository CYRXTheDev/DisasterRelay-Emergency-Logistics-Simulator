extends CharacterBody2D
## Top-down 4-direction rescue boat controller.

const SPEED := 160.0

@onready var sprite: AnimatedSprite2D = $AnimatedSprite2D

func _ready() -> void:
	add_to_group("player")
	Game.reset_game()

func _physics_process(delta: float) -> void:
	if not Game.game_active:
		velocity = Vector2.ZERO
		move_and_slide()
		return

	var input_dir := Vector2.ZERO
	input_dir.x = Input.get_axis("ui_left", "ui_right")
	input_dir.y = Input.get_axis("ui_up", "ui_down")

	var moving := input_dir.length() > 0.0
	if moving:
		input_dir = input_dir.normalized()
		velocity = input_dir * SPEED
		if input_dir.x < 0.0:
			sprite.flip_h = true
		elif input_dir.x > 0.0:
			sprite.flip_h = false
	else:
		velocity = Vector2.ZERO

	Game.consume_fuel(moving, delta)
	move_and_slide()
