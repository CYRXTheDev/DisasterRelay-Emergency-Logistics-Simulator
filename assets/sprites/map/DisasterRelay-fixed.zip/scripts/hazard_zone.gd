extends Area2D
## Flood hazard zone. Damages player health continuously while inside.

var _bodies_inside: Array[Node2D] = []

func _ready() -> void:
	body_entered.connect(_on_entered)
	body_exited.connect(_on_exited)

func _on_entered(body: Node2D) -> void:
	if body.is_in_group("player"):
		_bodies_inside.append(body)

func _on_exited(body: Node2D) -> void:
	_bodies_inside.erase(body)

func _process(delta: float) -> void:
	if _bodies_inside.size() > 0:
		Game.damage_health(Game.HAZARD_DAMAGE_RATE * delta)
