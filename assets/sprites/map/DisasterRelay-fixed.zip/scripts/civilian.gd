extends Area2D
## Rescuable civilian. Player touches it -> rescued.

func _ready() -> void:
	body_entered.connect(_on_body_entered)

func _on_body_entered(body: Node2D) -> void:
	if body.is_in_group("player"):
		Game.add_rescued()
		queue_free()
